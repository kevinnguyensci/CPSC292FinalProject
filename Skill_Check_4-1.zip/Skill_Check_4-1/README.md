# Yu-Gi-Oh! Master Duel

## Introduction

This project visualizes data gathered on the digital version of the trading card game Yu-Gi-Oh!: Yu-Gi-Oh! Master Duel. The game was released on February 2nd, 2022 and the data was collected in March. The data gathers various variables on 95 decks of cards; the variables are based on the cards each deck has and each deck has 40 cards. The 95 decks were selected from the top 19 most popular archetypes within the last 4 weeks (within the month of February). The five best performing decks of cards within each archetype were chosen. The data can be found within the data folder.

For the code to run properly, certain libraries are needed. To load the necessary libraries, install the following packages: 
install.packages("ggplot2")
install.packages("animation")
install.packages("magick")
install.packages("htmlTable")
install.packages("BayesFactor").

The code to install these packages are included in the R Markdown file.

The code also needs the Project-1-DataSet.csv file found in the data folder.

This project visualizes the data in the form of .gif files. The .gif files are created by formulating a series of plots; these plots will appear one after another within the file with a set interval of time in between each plot. The .gif files were made using the saveGIF() function. The size of the gif in terms of width and height can be adjusted with ani.width/ani.height arguments for the function. The name of the gif can be adjusted with the movie.name argument. The interval of time in between each appearance of the images/plots can be adjusted with the interval argument. The saveGIF() function is found within the animation library.

To make the plots, the ggplot() function was used. The boxplots were made with geom_boxplot() and this is found within the boxplot_YGO() function. The scatterplots were made with geom_point() and this is found within the scatterplot_YGO() function.

The resulting visualization is found within the doc folder. boxplot.gif is a GIF that cycles through boxplots that graph the number of cards with a specific effect found within decks (Add Cards, Additional Summons, Removal, Revive, Negate, Boost) of differing Card Type Majorities (Monster, Spell, and Trap). 

The significance tests (ANOVA and Bayes factor) were summarized into a table, including TukeyHSD, using htmlTable. Captions were also added using the caption argument. 

To view the citations and references after knitting, the SK41_ref.bib and modern-language-association.csl files are needed within the doc folder. The reference style is MLA format. 